# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '74b809770900034bb0fc8a472318adc480432016e7de5121ea310fef9a9da174227e702cfb8d0efbee0b8443e977c4a3c345777486067043955a6a6841dfc45e'